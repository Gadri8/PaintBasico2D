package sm.aggl.graficos;

import java.awt.geom.Point2D;
import static java.lang.Math.abs;
import static java.lang.Math.min;

public class Elipse extends java.awt.geom.Ellipse2D.Double{

    public Elipse(Point2D pi, Point2D pf){
        super(min(pi.getX(), pf.getX()), min(pi.getY(), pf.getY()), abs(pi.getX()-pf.getX()), abs(pi.getY()-pf.getY()));
    }
    
    public void setLocation(Point2D p){
        super.setFrame(p.getX(), p.getY(), this.getWidth(), this.getHeight());
    }
    
    @Override
    public boolean contains(Point2D p){
        return super.contains(p.getX(), p.getY());
    }
    
    public void setFrame(Point2D pi, Point2D pf){
        super.setFrame(min(pi.getX(), pf.getX()), min(pi.getY(), pf.getY()), abs(pi.getX()-pf.getX()), abs(pi.getY()-pf.getY())); 
    }
}
