package sm.aggl.graficos;

import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

public class Punto extends Line2D.Double{
    
    public Punto(Point2D p){
        super(p,p);
    }
    
    public boolean isNear(Point2D p) {
        return this.ptSegDist(p) <= 2.0;
    }

    @Override
    public boolean contains(Point2D p) {
        return isNear(p);
    }

    public void setLocation(Point2D pos) {
        double dx = pos.getX() - this.getX1();
        double dy = pos.getY() - this.getY1();
        Point2D newp2 = new Point2D.Double(this.getX2() + dx, this.getY2() + dy);
        this.setLine(pos, newp2);
    }
}
