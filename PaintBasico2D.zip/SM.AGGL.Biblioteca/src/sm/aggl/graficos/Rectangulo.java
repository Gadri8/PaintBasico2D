package sm.aggl.graficos;

import java.awt.geom.Point2D;
import static java.lang.Math.*;

public class Rectangulo extends java.awt.geom.Rectangle2D.Double{
   
    public Rectangulo(Point2D pi, Point2D pf){
        super(min(pi.getX(), pf.getX()), min(pi.getY(), pf.getY()), abs(pi.getX()-pf.getX()), abs(pi.getY()-pf.getY()));
    }
    
    public void setLocation(Point2D p) {
        super.setFrame(p.getX(), p.getY(), this.getWidth(), this.getHeight());
    }
    
    @Override
    public boolean contains(Point2D p){
       return super.contains(p.getX(), p.getY());
    }
    
    @Override
    public void setFrameFromDiagonal(Point2D p1, Point2D p2){
        super.setFrameFromDiagonal(p1, p2);
    }

}
