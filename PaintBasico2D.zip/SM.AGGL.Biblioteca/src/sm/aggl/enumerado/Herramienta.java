package sm.aggl.enumerado;

public enum Herramienta {PUNTO,LINEA,RECTANGULO,ELIPSE,EDICION}
